"""Reporting and MIS module."""
